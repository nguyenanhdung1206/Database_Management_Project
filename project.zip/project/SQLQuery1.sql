create table Customer(
	customerid int identity(1,1) primary key,
	firstname varchar(50) not null,
	lastname varchar(50) not null,
	username varchar(30) not null,
	password varchar (30) not null
);
go

create table Customer_bank(
	customerid int foreign key references Customer(customerid),
	account_number int,
	bank_name varchar(50) not null,
	primary key (customerid,account_number)
);
go

create table Supplier(
	supplierid varchar(50) primary key,
	supplier_name varchar(50) not null
);
go

create table Supplier_location(
	supplierid varchar(50) foreign key references Supplier(supplierid),
	supplier_location varchar(200)
	primary key (supplierid)
);
go

create table Item(
	itemid varchar(100) primary key,
	item_name varchar(50) not null,
	item_price money not null,
	discount float,
	price as (item_price*(1-discount)),
	class as case when item_price<100000 then 'C'
					when item_price>100000 and item_price<1000000 then 'B'
					else 'A'
					end
);
go

go

create table Purchase(
	customerid int foreign key references Customer(customerid),
	itemid varchar(100) foreign key references Item(itemid),
	quantity int not null,
	purchase_date date not null
);
go

create table Ordered_to(
	supplierid varchar(50) foreign key references Supplier(supplierid),
	itemid varchar(100) foreign key references Item(itemid),
	quantity int not null,
	order_date date not null,
	primary key (supplierid,itemid)
);
go

create view Bill as
Select C.firstname+' '+C.lastname as customer_name,B.account_number as bank,
	   I.item_name as item, I.item_price as price, I.discount, P.quantity as amount,
	   P.purchase_date as date_of_purchase, (I.price*P.quantity) as total
from Customer C, Customer_bank B, Item I, Purchase P
where C.customerid=B.customerid and C.customerid=P.customerid and I.itemid=P.itemid
go
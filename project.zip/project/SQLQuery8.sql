select * from Customer

select * from Customer_bank

select * from Item

select * from Ordered_to

select * from Purchase

select * from Supplier

select * from Supplier_location

go
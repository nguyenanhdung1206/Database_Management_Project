Insert into Item (itemid,item_name,item_price,discount)
values ('TV2068','Television',20000000,0.1)
go

insert into Purchase
values (1,'TV2068',1,'2018-05-12')
go

insert into Ordered_to
values ('S090','TV2068',100,'2016-06-09')
go


Insert into Customer(firstname,lastname,username,password)
values('Nguyen','Dung','anhdung12','12061999')
go


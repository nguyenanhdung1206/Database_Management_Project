Insert into Customer_bank
values (1,10086946,'MBI')
go



insert into Supplier
values ('S090','Samsung')
go

insert into Supplier_location
values ('S090','Japan')
go

